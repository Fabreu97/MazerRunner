#include <stdio.h>
#include <stdlib.h>
#include "Maze.h"

#define LINHAS 21
#define COLUNAS 21
#define NOME_ARQUIVO "maze4.txt" //arquivo de texto localizado na raiz do projeto

int main()
{
    Maze *m = criarMaze(LINHAS, COLUNAS);
    carregarDadosDoArquivo(m, NOME_ARQUIVO);
    exibirLabirinto(m);
    destroiMaze(m);

    return 0;
}
